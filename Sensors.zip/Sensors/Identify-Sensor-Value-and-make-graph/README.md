# Identify-Sensor-Value-and-make-graph
Identify the android device sensor value and make graph(time and value)
