package com.example.sensors;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.content.Context;
import android.content.Intent;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements SensorEventListener{

    private TextView lightSensor, prosensor, accSensor, gyrsensor;

    private Sensor lsensor, psensor, asensor, gsensor;
    private SensorManager sm;

    Database cdb;

    //for counting time
    int ltime = 0;
    int ptime = 0;
    int atime = 0;
    int gtime = 0;

    public void lightClick(View view){
        Intent intent = new Intent(MainActivity.this, LightValueSee.class);
        startActivity(intent);
    }

    public void proClick(View view){
        Intent intent = new Intent(MainActivity.this, ProximityValueShow.class);
        startActivity(intent);
    }

    public void accClick(View view){
        Intent intent = new Intent(MainActivity.this, AccSensorValueShow.class);
        startActivity(intent);
    }

    public void gclick(View view){
        Intent intent = new Intent(MainActivity.this, GyroValueShow.class);
        startActivity(intent);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //hiding action bar
        getSupportActionBar().hide();

        cdb = new Database(MainActivity.this);

        //Toast.makeText(this, "End Time = "+ltime, Toast.LENGTH_SHORT).show();

        //Textview to write value
        lightSensor = (TextView)findViewById(R.id.lightSensor);
        prosensor = (TextView) findViewById(R.id.prosensor);
        accSensor = (TextView) findViewById(R.id.accSensor);
        gyrsensor = (TextView) findViewById(R.id.gyrsensor);

        //sensore manager
        sm = (SensorManager) getSystemService(SENSOR_SERVICE);

        // for sensor
        lsensor = sm.getDefaultSensor(Sensor.TYPE_LIGHT);
        psensor = sm.getDefaultSensor(Sensor.TYPE_PROXIMITY);
        asensor = sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        gsensor = sm.getDefaultSensor(Sensor.TYPE_GYROSCOPE);

        // sensor availability check...
        // if available then register
       if(lsensor == null){
           lightSensor.setVisibility(View.VISIBLE);
           lightSensor.setText("No Light Sensor");
       }else{
           sm.registerListener(MainActivity.this, lsensor, 1000000); // 1 second = 1000000 microseconds
       }

       if(psensor == null){
           prosensor.setVisibility(View.VISIBLE);
           prosensor.setText("Proximity Sensor Not Available");
       }else{
           sm.registerListener(MainActivity.this, psensor, 1000000);
       }

        if(asensor == null){
            accSensor.setVisibility(View.VISIBLE);
            accSensor.setText("Accelerometer Sensor Not Available");
        }else{
            sm.registerListener(MainActivity.this, asensor, 1000000);
        }

        if(gsensor == null){
            gyrsensor.setVisibility(View.VISIBLE);
            gyrsensor.setText("Gyroscope Sensor Not Available");
        }else{
            sm.registerListener(MainActivity.this, gsensor, 1000000);
        }
    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        Sensor sensor = event.sensor;

        //if it is light sensor
        if(sensor.getType() == Sensor.TYPE_LIGHT){
            float maxval = lsensor.getMaximumRange();
            float val = event.values[0];

            //this countdowntimer work for 5 min
            new CountDownTimer(300000, 1000) {
                @Override
                public void onTick(long millisUntilFinished) {
                    if(ltime <= 300){
                        ltime++;
                        cdb.insertData(ltime, val);
                    }
                }

                @Override
                public void onFinish() {

                }
            }.start();

            lightSensor.setVisibility(View.VISIBLE);
            lightSensor.setText("Max Value: "+String.valueOf(maxval)+"\nCurrent Value: "+String.valueOf(val)+" Lux");
        }

        //if it is proximity sensor
        if(sensor.getType() == Sensor.TYPE_PROXIMITY){
            float maxval = psensor.getMaximumRange();
            float val = event.values[0];

            new CountDownTimer(300000, 1000) {
                @Override
                public void onTick(long millisUntilFinished) {
                    if(ptime <= 300){
                        ptime++;
                        cdb.insertDataP(ptime, val);
                    }
                }

                @Override
                public void onFinish() {

                }
            }.start();

            prosensor.setVisibility(View.VISIBLE);
            prosensor.setText("Max Value: "+String.valueOf(maxval)+"\nCurrent Value: "+String.valueOf(val)+" cm");
        }

        //if it is ACCELEROMETER sensor
        if(sensor.getType() == Sensor.TYPE_ACCELEROMETER){
            String x, y, z;
            x = String.valueOf(event.values[0]);
            y = String.valueOf(event.values[1]);
            z = String.valueOf(event.values[2]);

            new CountDownTimer(300000, 1000) {
                @Override
                public void onTick(long millisUntilFinished) {
                    if(atime <= 300){
                        atime++;
                        cdb.insertDataA(atime, Float.valueOf(x));
                    }
                }

                @Override
                public void onFinish() {

                }
            }.start();

            accSensor.setVisibility(View.VISIBLE);
            accSensor.setText("X = "+x+"\nY = "+y+"\nZ = "+z);
        }

        //if it is gyroscope sensor
        if(sensor.getType() == Sensor.TYPE_GYROSCOPE){
            String y, z;
            float x = event.values[0];
            y = String.valueOf(event.values[1]);
            z = String.valueOf(event.values[2]);

            new CountDownTimer(300000, 1000) {
                @Override
                public void onTick(long millisUntilFinished) {
                    if(gtime <= 300){
                        gtime++;
                        cdb.insertDataG(gtime, x);
                    }
                }

                @Override
                public void onFinish() {

                }
            }.start();

            gyrsensor.setVisibility(View.VISIBLE);
            gyrsensor.setText("X = "+x+"\nY = "+y+"\nZ = "+z);
        }
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {

    }

    @Override
    protected void onResume() {
        super.onResume();
        //if you do not register again then it will not receive data after pause
        sm.registerListener(MainActivity.this, lsensor, 1000000);
        sm.registerListener(MainActivity.this, gsensor, 1000000);
        sm.registerListener(MainActivity.this, psensor, 1000000);
        sm.registerListener(MainActivity.this, asensor, 1000000);
    }

    @Override
    protected void onPause() {
        super.onPause();
        //if do not unregister SensorManager then it will get data in background
        //and use battery even when you close the application
        if(ltime == 300){
            sm.unregisterListener(MainActivity.this);
        }
    }

}