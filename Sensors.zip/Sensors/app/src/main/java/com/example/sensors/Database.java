package com.example.sensors;

import android.content.Context;
import android.database.Cursor;
import android.database.DatabaseUtils;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.HashMap;

public class Database extends SQLiteOpenHelper {

    static final private String DB_NAME = "SensorStroge";
    static final private String DB_TABLE= "LSensorValue";
    static final private String DB_TABLE1= "PSensorValue";
    static final private String DB_TABLE2= "ASensorValue";
    static final private String DB_TABLE3= "GLSensorValue";
    static final private int DB_VER = 1;

    Context context;
    SQLiteDatabase sdb;

    public Database(Context ctx){
        super(ctx, DB_NAME, null, DB_VER);
        context = ctx;
    }
    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE "+DB_TABLE+"(id integer primary key autoincrement, times integer, value float)");
        db.execSQL("CREATE TABLE "+DB_TABLE1+"(id integer primary key autoincrement, times integer, value float)");
        db.execSQL("CREATE TABLE "+DB_TABLE2+"(id integer primary key autoincrement, times integer, value float)");
        db.execSQL("CREATE TABLE "+DB_TABLE3+"(id integer primary key autoincrement, times integer, value float)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS "+DB_TABLE);
        db.execSQL("DROP TABLE IF EXISTS "+DB_TABLE1);
        db.execSQL("DROP TABLE IF EXISTS "+DB_TABLE2);
        db.execSQL("DROP TABLE IF EXISTS "+DB_TABLE3);
        onCreate(db);
    }

    //insert data of light sensor
    public void insertData(int time, float value){
        sdb = getWritableDatabase();
        sdb.execSQL("INSERT INTO "+DB_TABLE+" (times, value) VALUES('"+time+"','"+value+"')");
    }

    //insert data of proximity sensor
    public void insertDataP(int time, float value){
        sdb = getWritableDatabase();
        sdb.execSQL("INSERT INTO "+DB_TABLE1+" (times, value) VALUES('"+time+"','"+value+"')");
    }

    //insert data of ACC sensor
    public void insertDataA(int time, float value){
        sdb = getWritableDatabase();
        sdb.execSQL("INSERT INTO "+DB_TABLE2+" (times, value) VALUES('"+time+"','"+value+"')");
    }

    //insert data of GYRO sensor
    public void insertDataG(int time, float value){
        sdb = getWritableDatabase();
        sdb.execSQL("INSERT INTO "+DB_TABLE3+" (times, value) VALUES('"+time+"','"+value+"')");
    }

    //get data of light sensor
    public HashMap getData(){
        sdb = getReadableDatabase();
        Cursor cr = sdb.rawQuery("SELECT * FROM "+DB_TABLE, null);
        HashMap<Integer, Float> storeV = new HashMap<Integer, Float>();
        while (cr.moveToNext()){
            float value;
            int time;
            time = cr.getInt(1);
            value = cr.getFloat(2);
            storeV.put(time, value);
        }
        return storeV;
    }

    //get data of proximity sensor
    public HashMap getDataP(){
        sdb = getReadableDatabase();
        Cursor cr = sdb.rawQuery("SELECT * FROM "+DB_TABLE1, null);
        HashMap<Integer, Float> storeV = new HashMap<Integer, Float>();
        while (cr.moveToNext()){
            float value;
            int time;
            time = cr.getInt(1);
            value = cr.getFloat(2);
            storeV.put(time, value);
        }
        return storeV;
    }

    //get data to ACC sensor
    public HashMap getDataA(){
        sdb = getReadableDatabase();
        Cursor cr = sdb.rawQuery("SELECT * FROM "+DB_TABLE2, null);
        HashMap<Integer, Float> storeV = new HashMap<Integer, Float>();
        while (cr.moveToNext()){
            float value;
            int time;
            time = cr.getInt(1);
            value = cr.getFloat(2);
            storeV.put(time, value);
        }
        return storeV;
    }

    //get data of GRYO
    public HashMap getDataG(){
        sdb = getReadableDatabase();
        Cursor cr = sdb.rawQuery("SELECT * FROM "+DB_TABLE3, null);
        HashMap<Integer, Float> storeV = new HashMap<Integer, Float>();
        while (cr.moveToNext()){
            float value;
            int time;
            time = cr.getInt(1);
            value = cr.getFloat(2);
            storeV.put(time, value);
        }
        return storeV;
    }

}
