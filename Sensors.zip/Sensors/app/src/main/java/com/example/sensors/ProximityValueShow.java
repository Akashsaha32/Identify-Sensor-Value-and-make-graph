package com.example.sensors;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.jjoe64.graphview.GraphView;
import com.jjoe64.graphview.series.DataPoint;
import com.jjoe64.graphview.series.LineGraphSeries;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;

public class ProximityValueShow extends AppCompatActivity {
    GraphView graphView;

    Database cdb;
    HashMap<Integer, Float> storedData;

    LineGraphSeries<DataPoint> series;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_proximity_value_show);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        graphView = (GraphView) findViewById(R.id.proGraph);

        cdb = new Database(ProximityValueShow.this);

        series = new LineGraphSeries<DataPoint>();

        storedData = cdb.getDataP();
        Set keys = storedData.keySet();

        for(Iterator i = keys.iterator(); i.hasNext();){
            int key = (Integer) i.next();
            float value = (Float) storedData.get(key);
            // add to graph serice
            series.appendData(new DataPoint(key, value), true, 300);
        }
        graphView.addSeries(series);
    }

    @Override
    public boolean onSupportNavigateUp() {
        finish();
        return super.onSupportNavigateUp();
    }
}